exports.handler = function(event, context, callback) {
   console.log("Hello world");
   callback(null, "some success message");
}
